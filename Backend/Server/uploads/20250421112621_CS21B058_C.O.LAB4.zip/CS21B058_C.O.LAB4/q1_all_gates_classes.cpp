#include <iostream>
#include <string>
#define delayyy 1;
using namespace std;


class ANDGate {
private:
    bool input1, input2;
public:
    ANDGate(bool i1, bool i2,int delay) {
        input1 = i1;
        input2 = i2;
    }

    bool getOutput() {
        return (input1 && input2);
    }
    int get_delay(){
        return delayyy;
    }
};
class ORGate {
private:
    bool input1, input2;
public:
    ORGate(bool i1, bool i2,int delay) {
        input1 = i1;
        input2 = i2;
    }

    bool getOutput() {
        return (input1 || input2);
    }
    int get_delay(){
        return delayyy;
    }
};
class NORGate {
private:
    bool input1, input2;
public:
    NORGate(bool i1, bool i2,int delay) {
        input1 = i1;
        input2 = i2;
    }

    bool getOutput() {
        return (!(input1 || input2));
    }
    int get_delay(){
        return delayyy;
    }
};
class NANDGate {
private:
    bool input1, input2;
public:
    NANDGate(bool i1, bool i2,int delay) {
        input1 = i1;
        input2 = i2;
    }


    bool getOutput() {
        cout<<delayyy;
        return (!(input1 && input2));
        
    }
    int get_delay(){
        return delayyy;
    }
};
class XORGate {
private:
    bool input1, input2;
public:
    XORGate(bool i1, bool i2,int delay) {
        input1 = i1;
        input2 = i2;
    }

    bool getOutput() {
        return ((input1^input2));
    }
    int get_delay(){
        return delayyy;
    }
};
class XNORGate {
private:
    bool input1, input2;
public:
    XNORGate(bool i1, bool i2,int delay) {
        input1 = i1;
        input2 = i2;
    }

    bool getOutput() {
        return (!(input1^input2));
    }
    int get_delay(){
        return delayyy;
    }
};
