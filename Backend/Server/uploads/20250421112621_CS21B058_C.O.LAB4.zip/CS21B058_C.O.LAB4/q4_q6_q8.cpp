#include <iostream>
#include <vector>
#include "q1_all_gates_classes.cpp"
using namespace std;


class HalfAdder {
    public:
    string input1;
    string input2;
    bool sum;
    bool carry;
    HalfAdder(string s1, string s2){
        input1= s1;
        input2= s2;

    }
    int summ(){
         bool in1= input1[input1.length()-1] - '0';
        bool in2= input2[input2.length()-1] - '0';
        XORGate x(in1, in2,1);
        return x.getOutput();
    }
    int carryy(){
        bool in1= input1[input1.length()-1] - '0';
        bool in2= input2[input2.length()-1] - '0';
        ANDGate x(in1, in2,1);
        return x.getOutput();
    }
};
class StringtoBinary {
    public:
    int inputSize(string s){
        int n;
        string temporary= "";
        int i=0;
        for(i=0; s[i]!='b'; i++){
            temporary += s[i];
        }
        n= stoi(temporary);
        return n;
    } 
    vector<bool> convert(string s, int n){
        vector<bool> v(n);
        int i=0;
        for(i=0; s[i]!='b'; i++);
        for(int j=i+1; j<s.length(); j++){
            if(s[j]=='1'){
                v[j-i-1]= 1;
            }
            else{
                v[j-i-1]= 0;
            }
        }
        return v;
    }
};

class FullAdder {
    public:
    string input1;
    string input2;
    bool sum;
    bool carryIn;
    bool carryOut;
    FullAdder(string s1, string s2, bool c){
        input1= s1;
        input2= s2;
        carryIn= c;
  
    }
    int summ(){
         bool in1= input1[input1.length()-1] - '0';
        bool in2= input2[input2.length()-1] - '0';
        XORGate x(in1, in2,1);
        int y=x.getOutput();
        XORGate x1(y,carryIn,1);
        return x1.getOutput();
    }
    int carryy(){
        bool in1= input1[input1.length()-1] - '0';
        bool in2= input2[input2.length()-1] - '0';
        ANDGate x(in1, in2,1);
        int y=x.getOutput();
        XORGate x1(in1,in2,1);
        int z=x1.getOutput();
        ANDGate x2(carryIn,z,1);
        int a=x2.getOutput();
        ORGate x3(y,a,1);
        int b=x3.getOutput();
        return b;
       
    }


};


class NBitAdder {
  private:
    int n;
    vector<int> a, b, c_out, sum;

  public:
    NBitAdder(int n) {
      this->n = n;
      a.resize(n);
      b.resize(n);
      c_out.resize(n + 1);
      sum.resize(n);
    }

    void setInputs(string a_str, string b_str) {
      for (int i = 0; i < n; i++) {
        a[i] = a_str[n - i - 1] - '0';
        b[i] = b_str[n - i - 1] - '0';
      }
    }

    void add() {
      c_out[0] = 0;
      for (int i = 0; i < n; i++) {
        sum[i] = a[i] ^ b[i] ^ c_out[i];
        c_out[i + 1] = (a[i] & b[i]) | (a[i] & c_out[i]) | (b[i] & c_out[i]);
      }
    }

    void printAnswer() {
      for (int i = n - 1; i >= 0; i--) {
        cout << sum[i];
      }
      cout << endl;
    }
};

class CarryLookaheadAdder {

 public:
       int sizeo;
    vector<bool> input1, input2, g, p, carry, sum;
    CarryLookaheadAdder(string in1,string in2,int n) {
      this->sizeo = n;
      input1.resize(n);
      input2.resize(n);
      g.resize(n);
      p.resize(n);
      carry.resize(n + 1);
      sum.resize(n);
        for (int i = 0; i < n; i++) {
        input1[i] = in1[n - i - 1] - '0';
        input2[i] = in2[n - i - 1] - '0';
      }
    }



    void produce_g_and_p() {
      g[0] = input1[0] & input2[0];
      p[0] = input1[0] | input2[0];
      for (int i = 1; i < sizeo; i++) {
        g[i] = input1[i] & input2[i];
        p[i] = input1[i] | input2[i];
        // g[i] =g[i]| p[i] & g[i - 1];
        // p[i] =p[i]& p[i - 1];
      }
    }

    void producecarry() {
      carry[0] = 0;
      for (int i = 1; i <= sizeo; i++) {
        carry[i] = p[i - 1] & carry[i - 1];
        carry[i] =carry[i]|| g[i - 1];
      }
    }

    void producesum() {
      for (int i = 0; i < sizeo; i++) {
        sum[i] = input1[i] ^ input2[i] ^ carry[i];
      }
    }

    void add() {
      produce_g_and_p();
      producecarry();
      producesum();
    }


  
};


//menu-driven like program
int main() {
    string inst;
    cin>>inst;
    if(inst=="hadder"){
        string s1, s2;
        cin>>s1>>s2;
        HalfAdder ha(s1, s2);
        cout<<"Sum- "<<ha.summ()<<endl<<"Carry out- "<<ha.carryy()<<endl;
        cout<<"half adder sum delay is 1"<<endl;
         cout<<"half adder carry delay is 1"<<endl;
    }
    else if(inst=="fadder"){
        string s1, s2;
        bool c;
        cin>>s1>>s2>>c;
        FullAdder fa(s1, s2, c);
        cout<<"Sum- "<<fa.summ()<<endl<<"Carry out- "<<fa.carryy()<<endl;
        cout<<"full adder sum delay is 2"<<endl;
         cout<<"full adder carry delay is 3"<<endl;
    }
    else if(inst=="radder"){
        int n;
  cout << "Enter the number of bits: ";
  cin >> n;
  NBitAdder adder(n);
  string a_str, b_str;
  cout << "Enter the first " << n << "-bit binary number in 1bxxxx format ";
  cin >> a_str;
  cout << "Enter the second " << n << "-bit binary number in 1bxxxx format ";
  cin >> b_str;
  adder.setInputs(a_str.erase(0,2), b_str.erase(0,2));
  adder.add();
  cout << "The sum is: ";
  adder.printAnswer();
  cout<<" sum delay is "<<2*n-1<<endl;
         cout<<" carry delay is "<<2*n<<endl;
    }
    else if(inst=="cla"){
      string s1,s2;
      cout << "Enter the first  binary number in 1bxxxx format ";
        cin>>s1;

        cout << "Enter the first  binary number in 1bxxxx format ";
         cin>>s2;
        int n=s1.length()-2;
        CarryLookaheadAdder cld(s1.erase(0,2),s2.erase(0,2),n);
        cld.add();
        vector<bool>sumo=cld.sum;
        for(int i=n-1;i>=0;i--)
        {
            cout<<sumo[i]<<" ";
        }
        cout<<endl;
        cout<<"the delay for sum is 3"<<", the delay for carry is 4"<<endl;
  
    }

    return 0;
}