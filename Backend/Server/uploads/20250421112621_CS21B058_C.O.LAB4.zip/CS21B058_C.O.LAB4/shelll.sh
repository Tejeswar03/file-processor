#!/bin/sh
g++ q4_q6_q8.cpp -o teja
if [[ $? == 0 ]]; then
    ./teja
fi